from fastapi import APIRouter
from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

# db functions
from app.database.db import get_session

# db models
from app.database.models.project.run_models import Run, RunCreate, RunRead

router = APIRouter(
    prefix="/run",
    tags=["run"],
    responses={404: {"description": "Not found"}},
)


##################
# Run
##################

@router.get("/new", response_model=RunRead)
async def new_run(session: AsyncSession = Depends(get_session)):
    run = await Run.create(RunCreate(name= await Run.nextName(session)),session)
    
    return run

@router.get("/start", response_model=RunRead)
async def start_run(session: AsyncSession = Depends(get_session)):
    run = await Run.startRun(session)
    
    
    return run
