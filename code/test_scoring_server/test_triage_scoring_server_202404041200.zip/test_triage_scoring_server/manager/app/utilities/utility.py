

criticalTypes = {
    'hemorrhage': 'severe_hemorrhage', 
    'distress': 'respiratory_distress'
    }
vitalTypes = {
    'heart': 'hr',
    'respiratory': 'rr'
    }
injuryTypes = {
        'trauma_head' : 'trauma_head',
        'trauma_torso' : 'trauma_torso',
        'trauma_lower_ext' : 'trauma_lower_ext',
        'trauma_upper_ext' : 'trauma_upper_ext',
        'alertness_ocular' : 'alertness_ocular',
        'alertness_verbal' : 'alertness_verbal',
        'alertness_motor' : 'alertness_motor'
        }

reportLimit = 15
runLength = 30*60