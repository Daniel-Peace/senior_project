from typing import Optional
from uuid import UUID

from sqlmodel import SQLModel, Field, Column, String, select
from sqlalchemy.ext.asyncio import AsyncSession

from .shared_models import ActiveRecord, BaseModel



class UserBaseCore(SQLModel):
    full_name: str
    username: str = Field(sa_column=Column("username", String, unique=True))
    is_active: bool 
    is_superuser: bool
    issued: int


class UserCreateCore(UserBaseCore):
    pass
    
class UserCore(UserBaseCore, ActiveRecord, BaseModel):
    

    @classmethod
    async def get_by_username(cls, username: str, session: AsyncSession):
        stmt = select(cls).where(cls.username == username)
        result = await session.execute(stmt)
        return result.scalars().first()
   

    
