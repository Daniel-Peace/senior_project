from datetime import datetime, timedelta
from typing import Any, Union

from jose import jwt


ALGORITHM = "HS256"
SECRET_KEY = 'THISKEYWILLBECHANGED'
ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 8

def create_access_token(
    subject: Union[str, Any],issued: str
) -> str:
    to_encode = {"sub": str(subject), "i": issued}
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt
