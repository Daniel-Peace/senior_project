from ..core.general_models import ParamsCore

class Params(ParamsCore, table=True):
    __tablename__ = "params"




