from datetime import datetime
from fastapi import HTTPException
from sqlalchemy.future import select
from sqlmodel import SQLModel, Field
from typing import Optional
from .shared_models import ActiveRecord

##################
# Run
##################

class RunBaseCore(SQLModel):
    
    start: Optional[datetime]
    name: str


class RunCore(RunBaseCore, ActiveRecord):
    id: Optional[int] = Field(default=None, nullable=False, primary_key=True)

    @classmethod
    async def latest(cls, session):
        locations = []
        try:
            stmt = select(cls).order_by(cls.id.desc())
            results = await session.execute(stmt)
            if results is None:
                raise HTTPException(status_code=404, detail=f"{cls.__name__}s with box_id  not found")
            locations = results.scalars().first()
        except ValueError:
            raise HTTPException(status_code=404, detail=f"{cls.__name__}s with box_id  not found")
        return locations    

    @classmethod
    async def startRun(cls, session):
        try:
            current = await cls.latest(session)
            current.start = datetime.utcnow()
            session.add(current)
            await session.commit()            
        except ValueError:
            raise HTTPException(status_code=404, detail=f"{cls.__name__}s with box_id  not found")
        return current
    

    @classmethod
    async def nextName(cls, session):
        try:
            current = await cls.latest(session)
            
            nextNumber = current.id+1
            name = "Run{}".format(nextNumber)

            
        except ValueError:
            raise HTTPException(status_code=404, detail=f"{cls.__name__}s with box_id  not found")
        return name
    
class RunCreateCore(RunBaseCore):
    pass


class RunReadCore(RunBaseCore):
    id: int
