from typing import Optional
from uuid import UUID
from app.database.models.core.user_models import UserCore, UserCreateCore
from sqlmodel import SQLModel, Field, Relationship
from app.database.models.project.team_models import Team

class User(UserCore, table=True):
    __table_name__ = 'user'
    team_id: Optional[UUID] = Field(default=None, foreign_key="team.id")
    team: "Team" = Relationship(sa_relationship_kwargs={"lazy": "selectin"})
    

class UserCreate(UserCreateCore):
    id: Optional[UUID] = None
    team_id: Optional[UUID] = None


class Token(SQLModel):
    access_token: str
    token_type: str


class TokenPayload(SQLModel):
    sub: Optional[str] = None    
    i: Optional[str] = None
