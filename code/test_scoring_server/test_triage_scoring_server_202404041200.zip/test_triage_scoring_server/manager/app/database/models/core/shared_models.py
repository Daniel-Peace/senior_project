from typing import Union, Optional
from fastapi import HTTPException
from uuid import UUID

from sqlalchemy.exc import IntegrityError
from sqlmodel import SQLModel, Field, Column
from sqlalchemy import text
from sqlalchemy_utils import UUIDType

class BaseModel(SQLModel):
    id: Optional[UUID] = Field(
        sa_column=Column(UUIDType(binary=False), server_default=text("gen_random_uuid()"), primary_key=True,
                         unique=True)
    )


class ActiveRecord(SQLModel):
    __mapper_args__ = {"eager_defaults": True}

    @classmethod
    async def by_id(cls, rid: str, session):
        obj = None
        try:
            obj = await session.get(cls, UUID(rid))
            if obj is None:
                raise HTTPException(status_code=404, detail=f"{cls.__name__} with id {rid} not found")
        except ValueError:
            raise HTTPException(status_code=404, detail=f"{cls.__name__} with id {rid} not found")
        return obj

    @classmethod
    async def create(cls, source: Union[dict, SQLModel], session):
        if isinstance(source, SQLModel):
            obj = cls.from_orm(source)
        elif isinstance(source, dict):
            obj = cls.parse_obj(source)
        session.add(obj)
        try:
            await session.commit()
            await session.refresh(obj)
        except IntegrityError:
            await session.rollback()
        return obj
