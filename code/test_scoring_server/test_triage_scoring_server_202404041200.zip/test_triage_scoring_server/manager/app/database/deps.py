from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt
from app.database.models.project.user_models import TokenPayload, User
from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession

from app.utilities import security

from app.database.db import get_session


reusable_oauth2 = OAuth2PasswordBearer(
    tokenUrl=f"api/login/token"
)


async def get_current_user(
    session: AsyncSession = Depends(get_session), token: str = Depends(reusable_oauth2)
) -> User:
    
    try:
        
        payload = jwt.decode(
            token, security.SECRET_KEY, algorithms=[security.ALGORITHM]
        )
        token_data = TokenPayload(**payload)
    except (jwt.JWTError, ValidationError) as ex:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Could not validate credentials",
        )
    user: User = await User.by_id(token_data.sub,session) 
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if str(user.issued) != token_data.i:
        raise HTTPException(status_code=404, detail="Token expired")
    return user


def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user