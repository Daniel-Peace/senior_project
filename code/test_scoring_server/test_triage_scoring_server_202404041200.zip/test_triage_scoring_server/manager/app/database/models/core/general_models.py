from fastapi import HTTPException
from sqlalchemy.future import select
from sqlmodel import SQLModel, Field, Column, String

from .shared_models import BaseModel, ActiveRecord



class ParamsBaseCore(SQLModel):
    key: str = Field(sa_column=Column("key", String, unique=True))
    value: str


class ParamsCore(ParamsBaseCore, BaseModel, ActiveRecord):

    @classmethod
    async def by_key(cls, key: str, session):
        obj = None
        try:
            results = await session.execute(select(cls).where(cls.key == key))
            obj = results.scalars().first()
        except ValueError:
            raise HTTPException(status_code=404, detail=f"{cls.__name__} with key {key} not found")
        return obj
