# TRIAGE SUBMISSION SERVER

This is a basic FAST API application that mirrors the request and responses of the TRIAGE SUBMISSION SERVER

Only the report endpoints will be available for the event. 
```
/api/critical 
/api/vitals
/api/injury
/api/status
```

These endpoints require an Authorization token in the response header.

For the test application this header is
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4M2Q3OGM4ZS04MzhhLTQ0NzctOWM3Yi02N2VmMTZlNWY3MTYiLCJpIjowfQ.i4KuwEtc5_6oIYz5TDWcdzl5bMkvCpLZTSZG2Avy84w
```

A different authorization token will be provided for the TRIAGE event.

In the FASTAPI UI, you can see these requests in action along with working curl commands.

To use the FASTAPI UI you have to click the Authorize button at the top of the docs page. Then click Autorize in the form. No fields need to be filled out.

This will not be available for the TRIAGE event.

# Example curl command


```
curl -X 'POST' \
  'http://localhost/api/critical' \
  -H 'accept: application/json' \
  -H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4M2Q3OGM4ZS04MzhhLTQ0NzctOWM3Yi02N2VmMTZlNWY3MTYiLCJpIjowfQ.i4KuwEtc5_6oIYz5TDWcdzl5bMkvCpLZTSZG2Avy84w' \
  -H 'Content-Type: application/json' \
  -d '{
  "system": "test_system",
  "casualty_id": 5,
  "type": "severe_hemorrhage",
  "value": 1
}'
```


# TEST endpoints

/api/run/new

This will create a new run reseting the report count limit.

/api/run/start

This will start the current run for this application the run time is 30 minutes.
NOTE: you can retrigger the start command to extend the start time (this is only for testing purposes)

## Build the TRIAGE SUBMISSION SERVER package


```sh
docker compose build
```

## Start The TRIAGE SUBMISSION SERVER

```sh
docker compose up
```

## Stop the TRIAGE SUBMISSION SERVER

```sh
docker compose down
```

#  TRIAGE SUBMISSION SERVER Navigation


## FastAPI UI 

```
http://localhost/docs
```

## FastAPI Documentation 

```
http://localhost/redoc
```
