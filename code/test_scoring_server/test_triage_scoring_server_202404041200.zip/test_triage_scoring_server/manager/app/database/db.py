import os

from sqlmodel import SQLModel
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.future import select

# db models so they get included for creation
from .models.project import general_models

DATABASE_URL = os.environ.get("DATABASE_URL")
DB_POOL_SIZE = 83
WEB_CONCURRENCY = 9
POOL_SIZE = max(DB_POOL_SIZE // WEB_CONCURRENCY, 5)

engine = create_async_engine(DATABASE_URL, echo=False, future=True, pool_size=POOL_SIZE, max_overflow=64)


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)


async def get_session() -> AsyncSession:
    async_session = sessionmaker(autocommit=False, autoflush=False, bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with async_session() as session:
        yield session


async def init_data():
    async for session in get_session():
        statement = select(general_models.Params).where(general_models.Params.key == "init")
        result = await session.execute(statement)
        param = result.scalars().first()
        if param is not None:
            if param.value.lower() == "false":
                from .models.populate import populate_database
                await populate_database(session)
        else:
            from .models.populate import populate_database
            await populate_database(session)

