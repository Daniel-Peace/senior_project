from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# router functions
from app.routers.base import api_router

# db functions
from app.database import db


def include_router(app):
    app.include_router(api_router, prefix="/api")


def start_application():
    app = FastAPI(openapi_url=f"/api/openapi.json")
    include_router(app)
    return app


app = start_application()
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def on_startup():
    await db.init_db()
    await db.init_data()


