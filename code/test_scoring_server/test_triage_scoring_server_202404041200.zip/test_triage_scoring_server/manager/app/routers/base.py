from .apis.version1 import route_run,route_login, route_report
from fastapi import APIRouter

api_router = APIRouter()
api_router.include_router(route_run.router)
api_router.include_router(route_login.router)
api_router.include_router(route_report.router)

