from ..core.team_models import TeamBaseCore, TeamCore, TeamCreateCore
##################
# Run
##################

class TeamBase(TeamBaseCore):
    pass

class Team(TeamCore, table=True):
    __table_name__ = 'team'

class TeamCreate(TeamCreateCore):
    pass


