from datetime import datetime
from enum import Enum
from typing import Optional
from app.database.models.core.shared_models import ActiveRecord, BaseModel
from sqlmodel import SQLModel, Field
from uuid import UUID
from sqlalchemy.future import select

class CaseInsensitiveEnum(Enum):
    @classmethod
    def _missing_(cls, value):
        value = value.lower()
        for member in cls:
            if member.lower() == value:
                return member
        return None



class ReportBase(SQLModel):
    system: str
    casualty_id: int
    type: str
    value: int

class ReportSubBase(ReportBase):
    team: str
    submitted: datetime = Field(default_factory=datetime.utcnow, nullable=False)
    run_id: Optional[int]
    user_id: str
    invalid: Optional[bool] = False
    
    @classmethod
    async def count(cls, type, run_id, session):
        count = 0
        try:
            stmt = select(cls).where(cls.run_id == run_id).where(cls.type == type).where(cls.invalid == False)
            results = await session.execute(stmt)
            count = len(results.all())
        except ValueError:
            raise HTTPException(status_code=404, detail=f"{cls.__name__}s count with run_id {run_id} and type {type} not found")
        return count
        


class CriticalReport(ReportSubBase,ActiveRecord, BaseModel, table=True):
    __tablename__ = "critical"


class VitalsBase(ReportBase):
    time_ago: float
    value: float



class VitalsReport(VitalsBase,ReportSubBase,ActiveRecord, BaseModel, table=True):
    __tablename__ = "vitals"


class InjuryReport(ReportSubBase,ActiveRecord, BaseModel, table=True):
    __tablename__ = "injury"



class CriticalValueEnum(int, Enum):
    one = 1
    zero = 0
class CriticalTypeEnum(str, CaseInsensitiveEnum):
    severe_hemorrhage = "severe_hemorrhage"
    respiratory_distress = "respiratory_distress"

class CriticalCreate(ReportBase):    
    type : CriticalTypeEnum
    value : CriticalValueEnum




class VitalsTypeEnum(str, CaseInsensitiveEnum):
    hr = "hr"
    rr = "rr"

class VitalsCreate(VitalsBase):    
    type : VitalsTypeEnum


class InjuryValueEnum(int, Enum):
    two = 2 
    one = 1
    zero = 0

class InjuryTypeEnum(str, CaseInsensitiveEnum):
    trauma_head = 'trauma_head'
    trauma_torso = 'trauma_torso'
    trauma_lower_ext = 'trauma_lower_ext'
    trauma_upper_ext = 'trauma_upper_ext'
    alertness_ocular = 'alertness_ocular'
    alertness_verbal = 'alertness_verbal'
    alertness_motor = 'alertness_motor'

class InjuryCreate(ReportBase):    
    type : InjuryTypeEnum
    value : InjuryValueEnum



class CriticalRead(CriticalReport):
    pass


class VitalsRead(VitalsReport):
    pass


class InjuryRead(InjuryReport):
    pass

class ReportResponse(SQLModel):    
    run: str
    team: str
    user: str
    system: str 
    clock: float
    report_id: UUID
    report_timestamp: datetime
    reports_remaining: int    
    report_status: str
    casualty_id: int
    type: str
    value: int

class VitalsResponse(ReportResponse):
    time_ago: float
    value: float
    



class CriticalCount(SQLModel):
    hemorrhage: Optional[int] = 0
    distress: Optional[int] = 0

class VitalsCount(SQLModel):
    heart: Optional[int] = 0
    respiratory: Optional[int] = 0

class InjuryCount(SQLModel):
    trauma_head: Optional[int] = 0
    trauma_torso: Optional[int] = 0
    trauma_lower_ext: Optional[int] = 0
    trauma_upper_ext: Optional[int] = 0
    alertness_ocular: Optional[int] = 0
    alertness_verbal: Optional[int] = 0
    alertness_motor: Optional[int] = 0

class ReportsCounts(SQLModel):
    critical: CriticalCount
    vitals: VitalsCount
    injury: InjuryCount


class StatusResponse(SQLModel):
    clock: float
    run: str
    team: str 
    user: str     
    remaining_reports: ReportsCounts
