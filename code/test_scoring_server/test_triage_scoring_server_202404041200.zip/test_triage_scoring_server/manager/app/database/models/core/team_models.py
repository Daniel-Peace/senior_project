from sqlmodel import SQLModel, Field, Column, String
from typing import Optional
from uuid import UUID
from .shared_models import ActiveRecord, BaseModel


##################
# Team
##################

class TeamBaseCore(SQLModel):
    name: str = Field(sa_column=Column("name", String, unique=True))
    location: Optional[str]


class TeamCore(TeamBaseCore, ActiveRecord, BaseModel):
    pass


class TeamCreateCore(TeamBaseCore):
    pass
