from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from app.database.models.project.user_models import Token, User
from sqlalchemy.ext.asyncio import AsyncSession
from app.utilities import security
from app.database.db import get_session

router = APIRouter(
    prefix="/login",
    tags=["login"],
    responses={404: {"description": "Not found"}},
)



@router.post("/token", response_model=Token)
async def login_access_token(
    db: AsyncSession = Depends(get_session)
) -> Any:
    """
    OAuth2 compatible token login, get an access token for future requests
    """
    
    user = await User.get_by_username('testuser',db)
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    elif not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    
    return {
        "access_token": security.create_access_token(
            user.id , user.issued
        ),
        "token_type": "bearer",
    }


