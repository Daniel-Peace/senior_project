from .project import  user_models, team_models, run_models
from .project.general_models import Params


async def populate_database(session):
    await populate_users(session)

    run = await run_models.Run.create(run_models.RunCreate(name="Run1"),session)

    item = Params(key="init", value="true")
    session.add(item)
    await session.commit()
    await session.close()



async def populate_users(session):
    item = team_models.TeamCreate(name ="Test Team")
    team = await team_models.Team.create(item, session)    
    item = user_models.UserCreate(id='83d78c8e-838a-4477-9c7b-67ef16e5f716',full_name="Test User",username="testuser",is_active=True,is_superuser=False,issued=0,team_id=team.id)
    await user_models.User.create(item,session)
    

