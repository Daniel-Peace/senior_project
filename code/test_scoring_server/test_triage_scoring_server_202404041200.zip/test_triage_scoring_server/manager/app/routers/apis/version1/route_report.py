from datetime import datetime
from typing import Any, Dict

from fastapi import APIRouter, Depends
from app.database.models.project.user_models import User
from app.database.models.project.report_models import InjuryCount, InjuryCreate, InjuryReport, CriticalCount, CriticalRead, CriticalCreate, CriticalReport, ReportResponse, ReportsCounts, StatusResponse, VitalsCount, VitalsCreate, VitalsReport, VitalsResponse
from app.database.models.project.run_models import Run
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import deps

from app.database.db import get_session

from app.utilities import utility

router = APIRouter(
    prefix="",
    tags=["report"],
    responses={404: {"description": "Not found"}},
)


@router.post("/critical", response_model=ReportResponse)
async def create_critical_report(
    *,
    session: AsyncSession = Depends(get_session),
    report: CriticalCreate,
    current_user: User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Create critical report.
    """

    item_dict = report.dict()
    item_dict["user_id"] = current_user.username 
    item_dict["type"] = report.type.lower()
    item_dict["team"] = current_user.team.name
    item:CriticalReport = await CriticalReport.create(item_dict,session)

    response: ReportResponse =  await create_response(session,item,current_user)
    return response



@router.post("/vitals", response_model=VitalsResponse)
async def create_vitals_report(
    *,
    session: AsyncSession = Depends(get_session),
    report: VitalsCreate,
    current_user: User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Create vitals report.
    """

    item_dict = report.dict()
    item_dict["user_id"] = current_user.username 
    item_dict["type"] = report.type.lower()
    item_dict["team"] = current_user.team.name
    item:VitalsReport = await VitalsReport.create(item_dict,session)
    
    response: ReportResponse = await create_response(session,item,current_user)
    
    vitalResponse = VitalsResponse(
        run=response.run,           
        team=response.team,
        user=response.user,
        system=response.system,
        clock=response.clock,
        report_id=response.report_id,
        report_timestamp=response.report_timestamp,
        reports_remaining=response.reports_remaining,
        report_status=response.report_status,
        casualty_id=response.casualty_id,
        type=response.type,
        value=response.value,
        time_ago=item.time_ago
    )    
    return vitalResponse



@router.post("/injury", response_model=ReportResponse)
async def create_injury_report(
    *,
    session: AsyncSession = Depends(get_session),
    report: InjuryCreate,
    current_user: User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Create injury report.
    """
    item_dict: Dict = report.dict()
    item_dict["user_id"] = current_user.username 
    item_dict["type"] = report.type.lower()
    item_dict["team"] = current_user.team.name
    item:InjuryReport = await InjuryReport.create(item_dict,session)

    return await create_response(session,item,current_user)
    




@router.get("/status", response_model=StatusResponse)
async def get_status(
    *,
    session: AsyncSession = Depends(get_session),
    current_user: User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Get Status of Current Run Reports
    """


    run: Run  = await  Run.latest(session)
    delta = 0
    if run and run.start:
        delta = (datetime.utcnow() - run.start).total_seconds()

    response: StatusResponse = StatusResponse(
        clock=delta,
        run =  run.name,
        team=current_user.team.name, 
        user=current_user.username, 
        remaining_reports=ReportsCounts(
            critical=CriticalCount(),
            vitals= VitalsCount(),
            injury= InjuryCount()
        )
    )


    for key in utility.injuryTypes.keys():
        count = await InjuryReport.count(utility.injuryTypes[key],run.id,session)   
        
        setattr(response.remaining_reports.injury,key,utility.reportLimit - count)

    for key in utility.vitalTypes.keys():
        count = await VitalsReport.count(utility.vitalTypes[key],run.id,session)        
        setattr(response.remaining_reports.vitals,key,utility.reportLimit - count)

    for key in utility.criticalTypes.keys():
        count = await CriticalReport.count(utility.criticalTypes[key],run.id,session)        
        setattr(response.remaining_reports.critical,key,utility.reportLimit - count)
    
    return response



async def create_response(session: AsyncSession, item, current_user: User):

    status = 'accepted'
    
    run: Run  = await Run.latest(session)
    delta = 0
    run_name = ""
    if run:
        run_name = run.name

    if run and run.start:
        delta = (item.submitted - run.start).total_seconds()
        item.run_id = run.id
        session.add(item)
        await session.commit()        
    else:
        status = "run not started"
        item.invalid = True
        session.add(item)
        await session.commit()       
        
    count = await item.count(item.type,run.id,session)
    remaining = utility.reportLimit - count
    if remaining < 0:
        status = "report limit exceeded"
        remaining = 0
        item.invalid = True
        session.add(item)
        await session.commit()

    if delta > utility.runLength:
        status = "time limit exceeded"
        item.invalid = True
        session.add(item)
        await session.commit()
        
    response: ReportResponse = ReportResponse(        
        run=run_name,
        team=current_user.team.name,
        user=current_user.username,
        system=item.system, 
        clock=delta,
        report_id=item.id,
        report_timestamp=datetime.now(),
        reports_remaining=remaining,    
        report_status=status,
        casualty_id=item.casualty_id,
        type=item.type,
        value=item.value
    )

    return response
