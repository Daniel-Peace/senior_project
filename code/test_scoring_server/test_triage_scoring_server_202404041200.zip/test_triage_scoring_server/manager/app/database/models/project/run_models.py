from ..core.run_models import RunBaseCore, RunCore, RunCreateCore, RunReadCore

##################
# Run
##################

class RunBase(RunBaseCore):
    pass

class Run(RunCore, table=True):
    __table_name__ = 'run'

class RunCreate(RunCreateCore):
    pass

class RunRead(RunReadCore):
    pass
